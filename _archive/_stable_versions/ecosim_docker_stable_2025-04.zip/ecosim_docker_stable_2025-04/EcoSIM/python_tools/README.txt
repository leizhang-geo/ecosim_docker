To prepare runfiles, do
ExampleInputWriter.py to write plant management file
SoilManagementWriter.py to write soil management file
SiteTopoWriter.py to write grid file
PlantTraitWriter.py to write possible pft parameterization file