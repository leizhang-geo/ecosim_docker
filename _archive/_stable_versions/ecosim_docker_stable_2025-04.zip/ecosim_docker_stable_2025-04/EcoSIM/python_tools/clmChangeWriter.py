import numpy as np
from netCDF4 import Dataset
import os,time,sys,argparse
from datetime import datetime
from array import array
import warnings
warnings.filterwarnings("ignore")
