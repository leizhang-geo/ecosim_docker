# f77src

|Directory        | Description                                  |
|-----------------|----------------------------------------------|
|driver/          | major driver files                           |
|ecosim_datatype  | Files define ecosim data types               |
|ecosim_mods/     | Essential code for ecosim derived from ecosys|
|ioutils/         | subroutines for input and output             |
|utils/           | Code for model enhancement                   |
