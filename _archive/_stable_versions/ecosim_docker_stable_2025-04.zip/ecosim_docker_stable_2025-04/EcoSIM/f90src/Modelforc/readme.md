#ecosim_mods

|File                 | Description                                                                         |
 |---------------------|-------------------------------------------------------------------------------------|
 |DayMod.f                |Reinitialize daily variables                                                         |
 |Hour1Mod.f              |Reinitialize hourly variables                                                        |
 |WthrMod.f               |Process weather variables                                                            |
