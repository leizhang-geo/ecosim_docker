# utils

|File             | Description                                  |
|-----------------|----------------------------------------------|
|abortutils.F90   | tools for safe abortion of the model         |
|data_kind_mod.F90| setting byte size for different data types   |
|TestMod.F90      | code to support regression tests             |
|EcoSimConst.F90  | module defines constant ecosim parameters    |
|fileUtil.F90     | module to handle files                       |
|getfilename.c    | C code to handle filenames                   |
|MiniMathMod.F90  | module with functions to handle some simple maths safely|
|timings.F90      | Code to do timing                            |
