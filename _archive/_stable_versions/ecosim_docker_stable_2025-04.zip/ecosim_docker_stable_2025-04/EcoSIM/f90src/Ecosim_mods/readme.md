#ecosim_mods

|File                 | Description                                                                         |
 |---------------------|-------------------------------------------------------------------------------------|
 |ExecMod.f               |Balance check of C, N, P, water and heat                                             |
 |GrosubMod.f             |Calculate all plant transformations                                                  |
 |HfuncMod.f              |Plant phenology calculation                                                          |
 |StarteMod.f             |Initialize soil chemistry variables                                                  |
 |StartqMod.f             |Initialize plant variables                                                           |
 |StartsMod.f             |Initialize soil variables                                                            |
 |VisualMod.f             |Output for model check                                                               |
 |WatsubMod.f             |Soil hydrothermal processes                                                          |
