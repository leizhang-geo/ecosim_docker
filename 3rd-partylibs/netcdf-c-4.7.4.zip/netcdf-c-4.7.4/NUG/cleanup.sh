#!/bin/bash

rm -rf html
rm -rf latex
rm -rf *~

