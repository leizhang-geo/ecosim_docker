#!/bin/sh

set -e

./tst_open_cdf5 ${srcdir}/bad_cdf5_begin.nc

