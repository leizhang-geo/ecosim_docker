/*********************************************************************
 *   Copyright 2018, UCAR/Unidata
 *   See netcdf/COPYRIGHT file for copying and redistribution conditions.
 *********************************************************************/

/* $Id$ */
/* $Header$ */

#include "config.h"
#include "netcdf.h"

int
NC_initialize(void)
{
    return NC_NOERR;
}
